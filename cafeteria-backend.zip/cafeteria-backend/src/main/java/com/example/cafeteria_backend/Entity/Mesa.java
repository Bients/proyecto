package com.example.cafeteria_backend.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mesas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Mesa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre; // Ej: "Mesa 1", "Barra 2"

    @Column(nullable = false)
    private Integer capacidad; // Número de sillas

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoMesa estado;

    // Opcional: Si en el futuro quieres guardar la posición X/Y para el mapa visual
    // private Integer posX;
    // private Integer posY;
}