package com.example.cafeteria_backend.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Entity
@Table(name = "clientes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String telefono;

    // Inicializamos en 0 por defecto para nuevos clientes
    @Column(nullable = false)
    private Integer visitas = 0;

    @Column(name = "total_gastado", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalGastado = BigDecimal.ZERO;
}