package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Dto.PedidoRequest;
import com.example.cafeteria_backend.Entity.*;
import com.example.cafeteria_backend.Repository.ClienteRepository;
import com.example.cafeteria_backend.Repository.PedidoRepository;
import com.example.cafeteria_backend.Repository.ProductoRepository;
import com.example.cafeteria_backend.Service.ClienteService;
import com.example.cafeteria_backend.Service.PedidoService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PedidoServiceImpl implements PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private ClienteService clienteService;

    @Override
    public List<Pedido> obtenerTodos() {
        return pedidoRepository.findAll();
    }

    @Override
    public Optional<Pedido> obtenerPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    @Override
    @Transactional
    public Pedido crearPedido(PedidoRequest request) {
        // 1. Recuperar Cliente
        Cliente cliente = clienteRepository.findById(request.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        // 2. Instanciar Pedido
        Pedido pedido = new Pedido();
        pedido.setMesa(request.getMesa());
        pedido.setCliente(cliente);
        // Estado y Fecha se ponen solos en @PrePersist
        
        BigDecimal totalPedido = BigDecimal.ZERO;

        // 3. Procesar Items y armar Detalles
        for (PedidoRequest.ItemPedidoRequest item : request.getItems()) {
            Producto producto = productoRepository.findById(item.getProductoId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            // Validar Stock
            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("Stock insuficiente: " + producto.getNombre());
            }

            // Descontar Stock
            producto.setStock(producto.getStock() - item.getCantidad());
            productoRepository.save(producto);

            // Crear Detalle
            DetallePedido detalle = new DetallePedido();
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecio());
            
            BigDecimal subtotal = producto.getPrecio().multiply(new BigDecimal(item.getCantidad()));
            detalle.setSubtotal(subtotal);

            // USANDO LA FUSIÓN: Método helper de la entidad Pedido
            // Esto asigna el detalle a la lista Y asigna el pedido al detalle
            pedido.agregarDetalle(detalle);
            
            totalPedido = totalPedido.add(subtotal);
        }

        pedido.setTotal(totalPedido);

        // 4. Guardar Todo (Cascada guarda los detalles)
        Pedido pedidoGuardado = pedidoRepository.save(pedido);

        // 5. Actualizar Cliente (Métricas)
        clienteService.actualizarMetricas(cliente.getId(), totalPedido);

        return pedidoGuardado;
    }

    @Override
    public Pedido cambiarEstado(Long id, EstadoPedido nuevoEstado) {
        return pedidoRepository.findById(id).map(pedido -> {
            pedido.setEstado(nuevoEstado);
            return pedidoRepository.save(pedido);
        }).orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    @Override
    public void eliminarPedido(Long id) {
        pedidoRepository.deleteById(id);
    }
}