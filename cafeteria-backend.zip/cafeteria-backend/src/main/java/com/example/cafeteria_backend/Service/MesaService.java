package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Entity.EstadoMesa;
import com.example.cafeteria_backend.Entity.Mesa;
import com.example.cafeteria_backend.Entity.Reserva;
import java.util.List;
import java.util.Optional;

public interface MesaService {
    // Gestión de Mesas
    List<Mesa> obtenerTodasMesas();
    Optional<Mesa> obtenerMesaPorId(Long id);
    Mesa guardarMesa(Mesa mesa);
    Mesa cambiarEstadoMesa(Long id, EstadoMesa estado);
    void eliminarMesa(Long id);

    // Gestión de Reservas
    List<Reserva> obtenerTodasReservas();
    Reserva crearReserva(Reserva reserva);
    void eliminarReserva(Long id);
}