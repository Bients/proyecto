package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Long> {
    
    // Útil para saber qué detalles incluyen cierto producto (para estadísticas)
    List<DetallePedido> findByProductoId(Long productoId);
}