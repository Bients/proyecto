package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Entity.Producto;
import java.util.List;
import java.util.Optional;

public interface ProductoService {
    List<Producto> obtenerTodos();
    Optional<Producto> obtenerPorId(Long id);
    Producto guardarProducto(Producto producto);
    Producto actualizarProducto(Long id, Producto producto);
    void eliminarProducto(Long id);
    List<Producto> buscarPorCategoria(String categoria);
}