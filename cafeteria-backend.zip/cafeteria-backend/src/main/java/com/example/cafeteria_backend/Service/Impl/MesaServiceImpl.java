package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Entity.EstadoMesa;
import com.example.cafeteria_backend.Entity.Mesa;
import com.example.cafeteria_backend.Entity.Reserva;
import com.example.cafeteria_backend.Repository.MesaRepository;
import com.example.cafeteria_backend.Repository.ReservaRepository;
import com.example.cafeteria_backend.Service.MesaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MesaServiceImpl implements MesaService {

    @Autowired
    private MesaRepository mesaRepository;
    
    @Autowired
    private ReservaRepository reservaRepository;

    // --- MESAS ---

    @Override
    public List<Mesa> obtenerTodasMesas() {
        return mesaRepository.findAll();
    }

    @Override
    public Optional<Mesa> obtenerMesaPorId(Long id) {
        return mesaRepository.findById(id);
    }

    @Override
    public Mesa guardarMesa(Mesa mesa) {
        return mesaRepository.save(mesa);
    }

    @Override
    public Mesa cambiarEstadoMesa(Long id, EstadoMesa estado) {
        return mesaRepository.findById(id).map(mesa -> {
            mesa.setEstado(estado);
            return mesaRepository.save(mesa);
        }).orElseThrow(() -> new RuntimeException("Mesa no encontrada"));
    }

    @Override
    public void eliminarMesa(Long id) {
        mesaRepository.deleteById(id);
    }

    // --- RESERVAS ---

    @Override
    public List<Reserva> obtenerTodasReservas() {
        return reservaRepository.findAll();
    }

    @Override
    public Reserva crearReserva(Reserva reserva) {
        // Lógica opcional: Al reservar, podríamos cambiar el estado de la mesa a RESERVADA automáticamente
        // pero a veces se reserva para mañana, así que mejor no cambiar el estado actual.
        return reservaRepository.save(reserva);
    }

    @Override
    public void eliminarReserva(Long id) {
        reservaRepository.deleteById(id);
    }
}