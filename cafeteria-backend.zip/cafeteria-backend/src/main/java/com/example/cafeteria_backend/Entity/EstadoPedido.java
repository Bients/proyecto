package com.example.cafeteria_backend.Entity;

public enum EstadoPedido {
    ACTIVO,
    COMPLETADO,
    CANCELADO
}