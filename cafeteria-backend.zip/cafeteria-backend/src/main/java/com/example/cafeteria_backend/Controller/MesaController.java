package com.example.cafeteria_backend.Controller;

import com.example.cafeteria_backend.Entity.EstadoMesa;
import com.example.cafeteria_backend.Entity.Mesa;
import com.example.cafeteria_backend.Entity.Reserva;
import com.example.cafeteria_backend.Service.MesaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class MesaController {

    @Autowired
    private MesaService mesaService;

    // --- ENDPOINTS DE MESAS ---

    @GetMapping("/mesas")
    public List<Mesa> listarMesas() {
        return mesaService.obtenerTodasMesas();
    }

    @PostMapping("/mesas")
    public Mesa crearMesa(@RequestBody Mesa mesa) {
        return mesaService.guardarMesa(mesa);
    }

    // PUT: /api/mesas/1/estado?estado=OCUPADA
    // Este endpoint es el que llamarás cuando hagas click en una mesa en el mapa
    @PutMapping("/mesas/{id}/estado")
    public ResponseEntity<Mesa> cambiarEstado(@PathVariable Long id, @RequestParam EstadoMesa estado) {
        try {
            return ResponseEntity.ok(mesaService.cambiarEstadoMesa(id, estado));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/mesas/{id}")
    public ResponseEntity<Void> eliminarMesa(@PathVariable Long id) {
        mesaService.eliminarMesa(id);
        return ResponseEntity.noContent().build();
    }

    // --- ENDPOINTS DE RESERVAS ---

    @GetMapping("/reservas")
    public List<Reserva> listarReservas() {
        return mesaService.obtenerTodasReservas();
    }

    @PostMapping("/reservas")
    public Reserva crearReserva(@RequestBody Reserva reserva) {
        return mesaService.crearReserva(reserva);
    }

    @DeleteMapping("/reservas/{id}")
    public ResponseEntity<Void> eliminarReserva(@PathVariable Long id) {
        mesaService.eliminarReserva(id);
        return ResponseEntity.noContent().build();
    }
}