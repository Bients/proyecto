package com.example.cafeteria_backend.Entity;

public enum MetodoPago {
    EFECTIVO,
    TARJETA,
    YAPE,
    PLIN
}