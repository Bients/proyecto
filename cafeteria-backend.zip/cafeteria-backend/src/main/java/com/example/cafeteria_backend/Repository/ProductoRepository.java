package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    
    // Al poner CategoriaNombre, Spring entiende: 
    // "Busca en el objeto 'categoria' el campo 'nombre'"
    List<Producto> findByCategoriaNombre(String nombre);
}