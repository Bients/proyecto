package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
    // Método vital para el Login
    Optional<Usuario> findByEmail(String email);
}