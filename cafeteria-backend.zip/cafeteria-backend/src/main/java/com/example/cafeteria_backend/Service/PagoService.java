package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Dto.PagoRequest;
import com.example.cafeteria_backend.Entity.Pago;
import java.util.List;

public interface PagoService {
    Pago procesarPago(PagoRequest pagoRequest);
    List<Pago> obtenerHistorialPagos();
}