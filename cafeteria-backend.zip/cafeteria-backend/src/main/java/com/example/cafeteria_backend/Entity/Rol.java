package com.example.cafeteria_backend.Entity;

public enum Rol {
    ADMIN,
    MESERO,
    CAJERO
}