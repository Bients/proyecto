package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Dto.DashboardDTO;
import com.example.cafeteria_backend.Entity.EstadoPedido;
import com.example.cafeteria_backend.Entity.Pedido;
import com.example.cafeteria_backend.Repository.ClienteRepository;
import com.example.cafeteria_backend.Repository.PedidoRepository;
import com.example.cafeteria_backend.Repository.ProductoRepository;
import com.example.cafeteria_backend.Service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public DashboardDTO obtenerResumenEstadisticas() {
        // 1. Contar Pedidos Activos
        long pedidosActivos = pedidoRepository.findByEstado(EstadoPedido.ACTIVO).size();

        // 2. Calcular Ventas del Día (Pedidos COMPLETADOS hoy)
        LocalDateTime inicioHoy = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDateTime finHoy = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        
        List<Pedido> pedidosHoy = pedidoRepository.findAll().stream()
                .filter(p -> p.getEstado() == EstadoPedido.COMPLETADO)
                .filter(p -> p.getFecha().isAfter(inicioHoy) && p.getFecha().isBefore(finHoy))
                .collect(Collectors.toList());

        BigDecimal ventasHoy = pedidosHoy.stream()
                .map(Pedido::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 3. Total de Clientes
        long totalClientes = clienteRepository.count();

        // 4. Productos con Stock Bajo (ejemplo: menos de 10 unidades)
        long stockBajo = productoRepository.findAll().stream()
                .filter(p -> p.getStock() < 10)
                .count();

        // 5. Ventas por Categoría (Para el PieChart de Angular)
        // Agrupamos todos los detalles de los pedidos de hoy por el nombre de su categoría
        Map<String, BigDecimal> ventasPorCat = pedidosHoy.stream()
                .flatMap(p -> p.getDetalles().stream())
                .collect(Collectors.groupingBy(
                        detalle -> detalle.getProducto().getCategoria().getNombre(),
                        Collectors.reducing(BigDecimal.ZERO, 
                                           detalle -> detalle.getSubtotal(), 
                                           BigDecimal::add)
                ));

        return new DashboardDTO(pedidosActivos, ventasHoy, totalClientes, stockBajo, ventasPorCat);
    }
}