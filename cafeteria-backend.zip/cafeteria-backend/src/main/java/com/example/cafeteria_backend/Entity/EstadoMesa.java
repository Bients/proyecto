package com.example.cafeteria_backend.Entity;

public enum EstadoMesa {
    LIBRE,
    OCUPADA,
    RESERVADA
}