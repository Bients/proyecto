package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Entity.Usuario;
import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    
    List<Usuario> obtenerTodos();
    
    Optional<Usuario> obtenerPorId(Long id);
    
    Usuario guardarUsuario(Usuario usuario);
    
    Usuario actualizarUsuario(Long id, Usuario usuario);
    
    void eliminarUsuario(Long id); // O desactivar
    
    // Método simple para validar credenciales
    Usuario login(String email, String password);
}