package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    
    // Para validar que no se repita el email al crear
    Optional<Cliente> findByEmail(String email);
    
    // Búsqueda por nombre (útil para autocompletado en pedidos)
    Optional<Cliente> findByNombre(String nombre);
}