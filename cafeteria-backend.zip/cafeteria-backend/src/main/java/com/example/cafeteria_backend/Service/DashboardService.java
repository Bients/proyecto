package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Dto.DashboardDTO;

public interface DashboardService {
    DashboardDTO obtenerResumenEstadisticas();
}