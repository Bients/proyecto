package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Dto.PedidoRequest;
import com.example.cafeteria_backend.Entity.Pedido;
import com.example.cafeteria_backend.Entity.EstadoPedido;
import java.util.List;
import java.util.Optional;

public interface PedidoService {
    List<Pedido> obtenerTodos();
    Optional<Pedido> obtenerPorId(Long id);
    Pedido crearPedido(PedidoRequest pedidoRequest);
    Pedido cambiarEstado(Long id, EstadoPedido nuevoEstado);
    void eliminarPedido(Long id);
}