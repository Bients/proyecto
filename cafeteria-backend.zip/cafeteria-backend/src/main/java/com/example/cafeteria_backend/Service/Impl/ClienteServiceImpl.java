package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Entity.Cliente;
import com.example.cafeteria_backend.Repository.ClienteRepository;
import com.example.cafeteria_backend.Service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public List<Cliente> obtenerTodos() {
        return clienteRepository.findAll();
    }

    @Override
    public Optional<Cliente> obtenerPorId(Long id) {
        return clienteRepository.findById(id);
    }

    @Override
    public Cliente guardarCliente(Cliente cliente) {
        // Al crear, nos aseguramos que visitas y gasto empiecen en 0 si vienen nulos
        if (cliente.getVisitas() == null) cliente.setVisitas(0);
        if (cliente.getTotalGastado() == null) cliente.setTotalGastado(BigDecimal.ZERO);
        return clienteRepository.save(cliente);
    }

    @Override
    public Cliente actualizarCliente(Long id, Cliente clienteDetalles) {
        return clienteRepository.findById(id).map(cliente -> {
            cliente.setNombre(clienteDetalles.getNombre());
            cliente.setEmail(clienteDetalles.getEmail());
            cliente.setTelefono(clienteDetalles.getTelefono());
            // Nota: No actualizamos visitas/gastado aquí manualmente, 
            // eso se hace vía lógica de negocio o se mantiene lo que había.
            return clienteRepository.save(cliente);
        }).orElseThrow(() -> new RuntimeException("Cliente no encontrado con id: " + id));
    }

    @Override
    public void eliminarCliente(Long id) {
        clienteRepository.deleteById(id);
    }

    @Override
    public void actualizarMetricas(Long id, BigDecimal montoCompra) {
        clienteRepository.findById(id).ifPresent(cliente -> {
            cliente.setVisitas(cliente.getVisitas() + 1);
            cliente.setTotalGastado(cliente.getTotalGastado().add(montoCompra));
            clienteRepository.save(cliente);
        });
    }
}