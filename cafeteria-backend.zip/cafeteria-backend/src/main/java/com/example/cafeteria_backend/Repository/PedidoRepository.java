package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.Pedido;
import com.example.cafeteria_backend.Entity.EstadoPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> findByEstado(EstadoPedido estado);
}