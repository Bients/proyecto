package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Entity.Categoria;
import com.example.cafeteria_backend.Repository.CategoriaRepository;
import com.example.cafeteria_backend.Service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaServiceImpl implements CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public List<Categoria> obtenerTodas() {
        return categoriaRepository.findAll();
    }

    @Override
    public Optional<Categoria> obtenerPorId(Long id) {
        return categoriaRepository.findById(id);
    }

    @Override
    public Categoria guardar(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    @Override
    public Categoria actualizar(Long id, Categoria detalles) {
        return categoriaRepository.findById(id).map(categoria -> {
            categoria.setNombre(detalles.getNombre());
            categoria.setDescripcion(detalles.getDescripcion());
            return categoriaRepository.save(categoria);
        }).orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
    }

    @Override
    public void eliminar(Long id) {
        categoriaRepository.deleteById(id);
    }
}