package com.example.cafeteria_backend.Repository;

import com.example.cafeteria_backend.Entity.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    // Buscar reservas de una fecha específica (útil para el calendario)
    List<Reserva> findByFechaHoraBetween(LocalDateTime inicio, LocalDateTime fin);
}