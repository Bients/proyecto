package com.example.cafeteria_backend.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.util.Map;

@Data
@AllArgsConstructor
public class DashboardDTO {
    private long pedidosActivos;
    private BigDecimal ventasDelDia;
    private long totalClientes;
    private long productosBajoStock; // Alerta para productos con stock < 10
    private Map<String, BigDecimal> ventasPorCategoria; // Datos para el gráfico de pastel
}