package com.example.cafeteria_backend.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "reservas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "mesa_id", nullable = false)
    private Mesa mesa;

    @Column(nullable = false)
    private String nombreCliente; // Nombre de quien reserva

    @Column(nullable = false)
    private LocalDateTime fechaHora; // Cuándo es la reserva

    @Column(nullable = false)
    private Integer numeroPersonas;
    
    // Un pequeño campo de notas (Ej: "Traer silla de bebé")
    private String observaciones;
}