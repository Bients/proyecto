package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Dto.PagoRequest;
import com.example.cafeteria_backend.Entity.EstadoPedido;
import com.example.cafeteria_backend.Entity.Pago;
import com.example.cafeteria_backend.Entity.Pedido;
import com.example.cafeteria_backend.Repository.PagoRepository;
import com.example.cafeteria_backend.Repository.PedidoRepository;
import com.example.cafeteria_backend.Service.PagoService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PagoServiceImpl implements PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    @Override
    @Transactional
    public Pago procesarPago(PagoRequest request) {
        // 1. Buscar el pedido
        Pedido pedido = pedidoRepository.findById(request.getPedidoId())
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        // 2. Validar que no esté ya pagado/completado
        if (pedido.getEstado() == EstadoPedido.COMPLETADO) {
            throw new RuntimeException("El pedido ya ha sido pagado y completado");
        }

        // 3. Validar que el dinero alcance
        if (request.getMontoPagado().compareTo(pedido.getTotal()) < 0) {
            throw new RuntimeException("El monto entregado es insuficiente");
        }

        // 4. Calcular vuelto
        BigDecimal vuelto = request.getMontoPagado().subtract(pedido.getTotal());

        // 5. Crear el registro del pago
        Pago pago = new Pago();
        pago.setPedido(pedido);
        pago.setMontoPagado(request.getMontoPagado());
        pago.setVuelto(vuelto);
        pago.setMetodo(request.getMetodo());

        // 6. Cambiar estado del pedido a COMPLETADO
        pedido.setEstado(EstadoPedido.COMPLETADO);
        pedidoRepository.save(pedido);

        return pagoRepository.save(pago);
    }

    @Override
    public List<Pago> obtenerHistorialPagos() {
        return pagoRepository.findAll();
    }
}