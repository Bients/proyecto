package com.example.cafeteria_backend.Dto;

import com.example.cafeteria_backend.Entity.MetodoPago;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class PagoRequest {
    private Long pedidoId;
    private BigDecimal montoPagado;
    private MetodoPago metodo;
}