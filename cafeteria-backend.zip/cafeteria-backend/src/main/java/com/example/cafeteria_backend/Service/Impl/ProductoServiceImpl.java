package com.example.cafeteria_backend.Service.Impl;

import com.example.cafeteria_backend.Entity.Producto;
import com.example.cafeteria_backend.Entity.Categoria; // Importar Categoria
import com.example.cafeteria_backend.Repository.ProductoRepository;
import com.example.cafeteria_backend.Repository.CategoriaRepository; // Importar Repositorio
import com.example.cafeteria_backend.Service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    // 1. Inyectamos el repositorio de categorías
    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public List<Producto> obtenerTodos() {
        return productoRepository.findAll();
    }

    @Override
    public Optional<Producto> obtenerPorId(Long id) {
        return productoRepository.findById(id);
    }

    @Override
    public Producto guardarProducto(Producto producto) {
        // 2. Buscamos la categoría completa por el ID que viene en el JSON
        if (producto.getCategoria() != null && producto.getCategoria().getId() != null) {
            Categoria cat = categoriaRepository.findById(producto.getCategoria().getId())
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
            
            // 3. Asignamos la categoría completa al producto
            producto.setCategoria(cat);
        }
        return productoRepository.save(producto);
    }

    @Override
    public Producto actualizarProducto(Long id, Producto productoDetalles) {
        return productoRepository.findById(id).map(producto -> {
            producto.setNombre(productoDetalles.getNombre());
            
            // También aplicamos la lógica aquí para que al actualizar se vea completo
            if (productoDetalles.getCategoria() != null && productoDetalles.getCategoria().getId() != null) {
                Categoria cat = categoriaRepository.findById(productoDetalles.getCategoria().getId())
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
                producto.setCategoria(cat);
            }
            
            producto.setPrecio(productoDetalles.getPrecio());
            producto.setStock(productoDetalles.getStock());
            return productoRepository.save(producto);
        }).orElseThrow(() -> new RuntimeException("Producto no encontrado"));
    }

    @Override
    public void eliminarProducto(Long id) {
        productoRepository.deleteById(id);
    }

    @Override
    public List<Producto> buscarPorCategoria(String categoria) {
        return productoRepository.findByCategoriaNombre(categoria);
    }
}