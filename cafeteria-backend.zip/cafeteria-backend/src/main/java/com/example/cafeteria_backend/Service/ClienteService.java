package com.example.cafeteria_backend.Service;

import com.example.cafeteria_backend.Entity.Cliente;
import java.util.List;
import java.util.Optional;

public interface ClienteService {
    
    List<Cliente> obtenerTodos();
    
    Optional<Cliente> obtenerPorId(Long id);
    
    Cliente guardarCliente(Cliente cliente);
    
    Cliente actualizarCliente(Long id, Cliente cliente);
    
    void eliminarCliente(Long id);
    
    // Método extra para actualizar métricas cuando se hace un pedido
    void actualizarMetricas(Long id, java.math.BigDecimal montoCompra);
}