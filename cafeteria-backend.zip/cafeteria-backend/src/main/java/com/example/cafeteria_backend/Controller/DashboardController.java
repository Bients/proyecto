package com.example.cafeteria_backend.Controller;

import com.example.cafeteria_backend.Dto.DashboardDTO;
import com.example.cafeteria_backend.Service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "http://localhost:4200") // Para tu frontend en Angular
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/estadisticas")
    public DashboardDTO obtenerEstadisticas() {
        return dashboardService.obtenerResumenEstadisticas();
    }
}