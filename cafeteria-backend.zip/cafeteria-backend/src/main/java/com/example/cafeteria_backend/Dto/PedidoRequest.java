package com.example.cafeteria_backend.Dto;

import lombok.Data;
import java.util.List;

@Data
public class PedidoRequest {
    private String mesa;
    private Long clienteId;
    private List<ItemPedidoRequest> items;

    @Data
    public static class ItemPedidoRequest {
        private Long productoId;
        private Integer cantidad;
    }
}