package com.example.cafeteria_backend.Controller;

import com.example.cafeteria_backend.Dto.PagoRequest;
import com.example.cafeteria_backend.Entity.Pago;
import com.example.cafeteria_backend.Service.PagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
@CrossOrigin(origins = "http://localhost:4200")
public class PagoController {

    @Autowired
    private PagoService pagoService;

    // POST: http://localhost:8080/api/pagos
    @PostMapping
    public ResponseEntity<?> registrarPago(@RequestBody PagoRequest pagoRequest) {
        try {
            return ResponseEntity.ok(pagoService.procesarPago(pagoRequest));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // GET: http://localhost:8080/api/pagos
    @GetMapping
    public List<Pago> listarPagos() {
        return pagoService.obtenerHistorialPagos();
    }
}